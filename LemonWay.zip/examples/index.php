<!DOCTYPE html>
<html lang="en">
<head>

    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <meta charset="utf-8">
    <title>
        Lemon Way PHP SDK Examples
    </title>
    <style type="text/css">
        table {
            width: 100%;
            border-collapse: collapse;
            text-align: left;
            color: #606060;
        }

        table td {
            vertical-align: middle;
            padding: 0.5em;
        }

        table thead tr td {
            background-color: White;
            vertical-align: middle;
            padding: 0.6em;
            font-size: 0.8em;
        }

        table thead tr th,
        table tbody tr.separator {
            padding: 0.5em;
            background-color: #909090;
            color: #efefef;
        }

        table tbody tr.separator{
            font-weight: bolder;
            background-color: #aaaaaa;
        }

        table tbody tr.sub-separator{
            font-weight: 900;
            padding-left: 10px;
            /*border-top: 1px black solid;*/
        }

        table tbody tr.sub td:first-child {
            padding-left: 10px;

        }

        table tbody tr:not(.separator):not(.sub-separator):nth-child(odd) {
            background-color: #fafafa;
        }

        table tbody tr:not(.separator):not(.sub-separator):nth-child(even) {
            background-color: #efefef;
        }

        table tbody tr:last-child {
            border-bottom: solid 1px #404040;
        }

        table tbody tr:not(.separator):not(.sub-separator):hover {
            background-color: #a8a8a8;
            color: #dadada;
        }

        a{
            text-decoration: none;
            border-bottom: 1px dotted #606060;
            color: #606060;
        }
    </style>
</head>
<body>

<table>
    <thead>
        <tr>
            <th>API</th>
            <th>Example</th>
            <th>Comments</th>
        </tr>
    </thead>
    <tbody>
        <tr class="separator">
            <td colspan="3">Wallets</td>
        </tr>
        <tr>
            <td>RegisterWallet</td>
            <td><a target="_blank" href="RegisterWallet.php">RegisterWallet</a></td>
            <td>&nbsp;</td>
        <tr>
            <td>GetWalletDetails</td>
            <td><a target="_blank" href="GetWalletDetails.php">GetWalletDetails</a></td>
            <td>&nbsp;</td>
        </tr>
        <tr>
            <td>UpdateWalletDetails</td>
            <td><a target="_blank" href="UpdateWalletDetails.php">UpdateWalletDetails</a></td>
            <td>&nbsp;</td>
        </tr>
        <tr>
            <td>UploadFile</td>
            <td><a target="_blank" href="UploadFile.php">UploadFile</a></td>
            <td>&nbsp;</td>
        </tr>
        <tr>
            <td>GetKycStatus</td>
            <td><a target="_blank" href="RegisterWallet.php">RegisterWallet</a></td>
            <td>&nbsp;</td>
        </tr>
        <tr>
            <td>GetWalletTransHistory</td>
            <td><a target="_blank" href="MoneyIn.php">MoneyIn</a></td>
            <td>&nbsp;</td>
        </tr>
        <tr>
            <td>UpdateWalletStatus</td>
            <td><a target="_blank" href="RegisterWallet.php">RegisterWallet</a>,
                <a target="_blank" href="SignDocument/index.php">SignDocument - SignDocumentInit</a></td>
            <td><em>Please fill a valid phone number for this example</em></td>
        </tr>
        <tr>
            <td>GetBalances</td>
            <td><a target="_blank" href="GetBalances.php">GetBalances</a></td>
            <td>&nbsp;</td>
        </tr>
        <tr class="separator">
            <td colspan="3">Money-in</td>
        </tr>
        <tr class="sub-separator">
            <td colspan="3">By Card</td>
        </tr>
        <tr class="sub">
            <td>MoneyInWebInit</td>
            <td><a target="_blank" href="MoneyIn_3D_Indirect/index.php">MoneyIn 3D Indirect - MoneyInWebInit</a></td>
            <td>
                Use <em>5017670000006700</em> for <em>success without 3D Secure</em>.<br />
                Use <em>5017670000001800</em> for <em>success wit 3D Secure</em>.<br />
                Use <em>5017670000000851</em> for <em>failure</em>.<br />
                For date, just put <em>a future one</em>.<br />
                For crypto, <em>any 3 digits number</em>.
            </td>
        </tr>
        <tr class="sub">
            <td>MoneyIn</td>
            <td><a target="_blank" href="MoneyIn.php">MoneyIn</a></td>
            <td>&nbsp;</td>
        </tr>
        <tr class="sub">
            <td>MoneyIn3DInit</td>
            <td><a target="_blank" href="MoneyIn_3D_Direct/confirm/index.php">MoneyIn 3D Direct - Confirm</a><br />
                <a target="_blank" href="MoneyIn_3D_Direct/authenticate/index.php">MoneyIn 3D Direct - Authenticate</a></td>
            <td>
                Use <em>5017670000001800</em> for <em>success wit 3D Secure</em>.<br />
                Use <em>5017670000000851</em> for <em>failure</em>.<br />
                For date, just put <em>a future one</em>.<br />
                For crypto, <em>any 3 digits number</em>.
            </td>
        </tr>
        <tr class="sub">
            <td>MoneyIn3DAuthenticate</td>
            <td><a target="_blank" href="MoneyIn_3D_Direct/authenticate/index.php">MoneyIn 3D Direct - Authenticate</a></td>
            <td>
                Use <em>5017670000001800</em> for <em>success wit 3D Secure</em>.<br />
                Use <em>5017670000000851</em> for <em>failure</em>.<br />
                For date, just put <em>a future one</em>.<br />
                For crypto, <em>any 3 digits number</em>.
            </td>
        </tr>
        <tr class="sub">
            <td>MoneyIn3DConfirm</td>
            <td><a target="_blank" href="MoneyIn_3D_Direct/confirm/index.php">MoneyIn 3D Direct - Confirm</a></td>
            <td>
                Use <em>5017670000001800</em> for <em>success wit 3D Secure</em>.<br />
                Use <em>5017670000000851</em> for <em>failure</em>.<br />
                For date, just put <em>a future one</em>.<br />
                For crypto, <em>any 3 digits number</em>.
            </td>
        </tr>
        <tr class="sub">
            <td>RegisterCard</td>
            <td><a target="_blank" href="Rebill.php">Rebill</a><br />
                <a target="_blank" href="MoneyIn_3D_Direct/authenticate/index.php">MoneyIn 3D Direct - Authenticate</a></td>
            <td>
                Use <em>5017670000001800</em> for <em>success wit 3D Secure</em>.<br />
                Use <em>5017670000000851</em> for <em>failure</em>.<br />
                For date, just put <em>a future one</em>.<br />
                For crypto, <em>any 3 digits number</em>.
            </td>
        </tr>
        <tr class="sub">
            <td>UnregisterCard</td>
            <td><a target="_blank" href="GetWalletDetails.php">GetWalletDetails</a></td>
            <td>&nbsp;</td>
        </tr>
        <tr class="sub">
            <td>MoneyInWithCardId</td>
            <td><a target="_blank" href="Rebill.php">Rebill</a></td>
            <td>&nbsp;</td>
        </tr>
        <tr class="sub">
            <td>MoneyInValidate</td>
            <td><a target="_blank" href="MoneyInValidate.php">MoneyInValidate</a></td>
            <td>&nbsp;</td>
        </tr>
        <tr class="sub-separator">
            <td colspan="3">By bank wire (SCT, Sepa Credit Transfer, IBAN)</td>
        </tr>
        <tr class="sub">
            <td>GetMoneyInIBANDetails</td>
            <td><a target="_blank" href="GetMoneyInIBANDetails.php">GetMoneyInIBANDetails</a></td>
            <td>&nbsp;</td>
        </tr>
        <tr class="sub-separator">
            <td colspan="3">By cheque</td>
        </tr>
        <tr class="sub">
            <td>MoneyInChequeInit</td>
            <td><a target="_blank" href="MoneyInCheque.php">MoneyInCheque</a></td>
            <td>&nbsp;</td>
        </tr>
        <tr class="sub">
            <td>GetMoneyInChequeDetails</td>
            <td><a target="_blank" href="MoneyInCheque.php">MoneyInCheque</a></td>
            <td>&nbsp;</td>
        </tr>
        <tr class="sub-separator">
            <td colspan="3">By SEPA Direct Debit (SDD)</td>
        </tr>
        <tr class="sub">
            <td>RegisterSddMandate</td>
            <td><a target="_blank" href="GetWalletDetails.php">GetWalletDetails</a>,
                <a target="_blank" href="SddMandate.php">Sdd Mandate</a></td>
            <td>&nbsp;</td>
        </tr>
        <tr class="sub">
            <td>UnregisterSddMandate</td>
            <td><a target="_blank" href="SddMandate.php">Sdd Mandate</a></td>
            <td>&nbsp;</td>
        </tr>
        <tr class="sub">
            <td>SignDocumentInit</td>
            <td><a target="_blank" href="SignDocument/index.php">SignDocument - SignDocumentInit</a></td>
            <td><em>Please fill a valid phone number for this example</em></td>
        </tr>
        <tr class="sub">
            <td>MoneyInSddInit</td>
            <td><a target="_blank" href="SignDocument/index.php">SignDocument - SignDocumentInit</a></td>
            <td><em>Please fill a valid phone number for this example</em></td>
        </tr>
        <tr class="sub">
            <td>GetMoneyInSdd</td>
            <td><a target="_blank" href="SignDocument/index.php">SignDocument - SignDocumentInit</a></td>
            <td><em>Please fill a valid phone number for this example</em></td>
        </tr>
        <tr class="sub-separator">
            <td colspan="3">By iDEAL</td>
        </tr>
        <tr class="sub">
            <td>MoneyInIDealConfirm</td>
            <td><a target="_blank" href="MoneyIn_iDeal/index.php">MoneyIn iDeal - MoneyInIDealConfirm</a></td>
            <td>&nbsp;</td>
        </tr>
        <tr class="sub">
            <td>MoneyInIDealInit</td>
            <td><a target="_blank" href="MoneyIn_iDeal/index.php">MoneyIn iDeal - MoneyInIDealInit</a></td>
            <td>&nbsp;</td>
        </tr>
        <tr class="sub-separator">
            <td colspan="3">By SOFORT</td>
        </tr>
        <tr class="sub">
            <td>MoneyInSofortInit</td>
            <td><a target="_blank" href="MoneyInSofort.php">MoneyInSofort</a></td>
            <td>&nbsp;</td>
        </tr>
        <tr class="sub-separator">
            <td colspan="3">By Neosurf</td>
        </tr>
        <tr class="sub">
            <td>MoneyInNeosurf</td>
            <td><a target="_blank" href="MoneyInNeosurf.php">MoneyInNeosurf</a></td>
            <td>&nbsp;</td>
        </tr>
         <tr class="sub-separator">
            <td colspan="3">Payment Form</td>
        </tr>
        <tr class="sub">
            <td>PaymentForm</td>
            <td><a target="_blank" href="CreatePaymentForm.php">PaymentForm</a></td>
            <td>&nbsp;</td>
        </tr>
        <tr>
            <td>GetMoneyInTransDetails</td>
            <td><a target="_blank" href="MoneyIn_3D_Indirect/index.php">MoneyIn 3D Indirect - MoneyInWebFinalize</a></td>
            <td>
                Use <em>5017670000006700</em> for <em>success without 3D Secure</em>.<br />
                Use <em>5017670000001800</em> for <em>success wit 3D Secure</em>.<br />
                Use <em>5017670000000851</em> for <em>failure</em>.<br />
                For date, just put <em>a future one</em>.<br />
                For crypto, <em>any 3 digits number</em>.
            </td>
        </tr>
        <tr class="separator">
            <td colspan="3">Money-out</td>
        </tr>
        <tr>
            <td>RegisterIBAN</td>
            <td><a target="_blank" href="MoneyOut.php">MoneyOut</a></td>
            <td>&nbsp;</td>
        </tr>
        <tr>
            <td>MoneyOut</td>
            <td><a target="_blank" href="MoneyOut.php">MoneyOut</a></td>
            <td>&nbsp;</td>
        </tr>
        <tr>
            <td>GetMoneyOutTransDetails</td>
            <td><a target="_blank" href="MoneyOut.php">MoneyOut</a></td>
            <td>&nbsp;</td>
        </tr>
        <tr class="separator">
            <td colspan="3">P2P</td>
        </tr>
        <tr>
            <td>GetPaymentDetails</td>
            <td><a target="_blank" href="SendPayment.php">SendPayment</a></td>
            <td>&nbsp;</td>
        </tr>
        <tr>
            <td>SendPayment</td>
            <td><a target="_blank" href="SendPayment.php">SendPayment</a></td>
            <td>&nbsp;</td>
        </tr>
        <tr class="separator">
            <td colspan="3">Other functions</td>
        </tr>
        <tr>
            <td>RefundMoneyIn</td>
            <td><a target="_blank" href="RefundMoneyIn.php">RefundMoneyIn</a></td>
            <td>&nbsp;</td>
        </tr>
        <tr>
            <td>GetChargebacks</td>
            <td><a target="_blank" href="GetChargebacks.php">GetChargebacks</a></td>
            <td>&nbsp;</td>
        </tr>
        <tr>
            <td>CreateVCC</td>
            <td><a target="_blank" href="CreateVCC.php">Create VCC</a></td>
            <td>&nbsp;</td>
        </tr>
        <tr>
            <td>GetWizypayAds</td>
            <td><a target="_blank" href="GetWizypayAds.php">GetWizypayAds</a></td>
            <td>&nbsp;</td>
        </tr>
    </tbody>
</table>


</body>
</html>
