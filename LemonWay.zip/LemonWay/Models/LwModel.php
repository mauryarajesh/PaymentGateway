<?php
namespace LemonWay\Models;
class LwModel {

}

?>