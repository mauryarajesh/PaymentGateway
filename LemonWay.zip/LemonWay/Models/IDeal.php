<?php
namespace LemonWay\Models;
class IDeal{
    const ISSUER_RABOBANK = '21';
    const ISSUER_ABN_AMRO = '31';
    const ISSUER_ING = '721';
    const ISSUER_SNS_BANK = '751';
    const ISSUER_VAN_LANSCHOT_BANKIERS = '161';
    const ISSUER_TRIODOS_BANK = '511';
    const ISSUER_ASN_BANK = '761';
    const ISSUER_REGIOBANK = '771';
    const ISSUER_KNAB_BANK = '801';

    const ISSUER_TEST_BANK = '121';

}
