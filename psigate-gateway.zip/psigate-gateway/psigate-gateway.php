

<?php
/*
 * Plugin Name: WooCommerce PsiGate Payment Gateway
 * Plugin URI: #
 * Description: PsiGate secure payment system and accept credit cards directly from your WooCommerce checkout page.
 * Author: Rajesh Maurya
 * Author URI: #
 * Version: 1.0.1
 *
 
 /*
 * This action hook registers our PHP class as a WooCommerce payment gateway
 */
add_filter( 'woocommerce_payment_gateways', 'psigate_add_gateway_class' );
function psigate_add_gateway_class( $gateways ) {
	$gateways[] = 'WC_Psigate_Gateway'; // your class name is here
	return $gateways;
}
 
/*
 * The class itself, please note that it is inside plugins_loaded action hook
 */
add_action( 'plugins_loaded', 'psigate_init_gateway_class' );
function psigate_init_gateway_class() {
 
	class WC_Psigate_Gateway extends WC_Payment_Gateway {
 
 		/**
 		 * Class constructor, more about it in Step 3
 		 */
 	public function __construct() {
 
	$this->id = 'psigate'; // payment gateway plugin ID
	$this->icon = 'https://www.psigate.com/wp-content/uploads/2014/01/psigate-logo.png'; // URL of the icon that will be displayed on checkout page near your gateway name
	$this->has_fields = true; // in case you need a custom credit card form
	$this->method_title = 'PsiGate Payment Gateway';
	$this->method_description = 'Description of psigate payment gateway'; // will be displayed on the options page
 
	// gateways can support subscriptions, refunds, saved payment methods,
	// but in this tutorial we begin with simple payments
	$this->supports = array(
		'products'
	);
 
	// Method with all the options fields
	$this->init_form_fields();
 
	// Load the settings.
	$this->init_settings();
	$this->title = $this->get_option( 'title' );
	$this->description = $this->get_option( 'description' );
	$this->enabled = $this->get_option( 'enabled' );
	$this->testmode = 'yes' === $this->get_option( 'testmode' );
	$this->private_key_cad = $this->testmode ? $this->get_option( 'test_private_key' ) : $this->get_option( 'private_key_cad' );
	$this->publishable_key_cad = $this->testmode ? $this->get_option( 'test_publishable_key' ) : $this->get_option( 'publishable_key_cad' );
	$this->private_key_usd = $this->testmode ? $this->get_option( 'test_private_key' ) : $this->get_option( 'private_key_usd' );
	$this->publishable_key_usd = $this->testmode ? $this->get_option( 'test_publishable_key' ) : $this->get_option( 'publishable_key_usd' );
 
	// This action hook saves the settings
	add_action( 'woocommerce_update_options_payment_gateways_' . $this->id, array( $this, 'process_admin_options' ) );
 
	// We need custom JavaScript to obtain a token
	add_action( 'wp_enqueue_scripts', array( $this, 'payment_scripts' ) );
 
	// You can also register a webhook here
	// add_action( 'woocommerce_api_{webhook name}', array( $this, 'webhook' ) );
  }
 
		/**
 		 * Plugin options, we deal with it in Step 3 too
 		 */
		 
		 
  public function init_form_fields(){
 
	$this->form_fields = array(
		'enabled' => array(
			'title'       => 'Enable/Disable',
			'label'       => 'Enable PsiGate Gateway',
			'type'        => 'checkbox',
			'description' => 'XML API Settings',
			'default'     => 'no'
		),
		'title' => array(
			'title'       => 'Title',
			'type'        => 'text',
			'description' => 'This controls the title which the user sees during checkout.',
			'default'     => 'Credit Card',
			'desc_tip'    => true,
		),
		'description' => array(
			'title'       => 'Description',
			'type'        => 'textarea',
			'description' => 'This controls the description which the user sees during checkout.',
			'default'     => 'Pay with your credit card via our super-cool payment gateway.',
		),
		'testmode' => array(
			'title'       => 'Test mode',
			'label'       => 'Enable Test Mode',
			'type'        => 'checkbox',
			'description' => 'Place the payment gateway in test mode using test API keys.',
			'default'     => 'yes',
			'desc_tip'    => true,
		),
		'test_publishable_key' => array(
			'title'       => 'Test Store ID',

			'type'        => 'text',
			'description' => 'PSiGate provides the test StoreID within the PSiGate in Real-Time XML API Doc. (teststore)',
		
			
		),
		'test_private_key' => array(
			'title'       => 'Test Pass Phrase',
			'type'        => 'text',			
			'description' => 'PSiGate provides the test Passphrase within the PSiGate in Real-Time XML API Doc. (psigate1234)',
		
			
		),
		'test_url' => array(
			'title'       => 'Realtime XML test URL',
			'type'        => 'text',			
			'description' => 'PSiGate’s testing environment supports a shared test account that you are welcome to use while you develop
and test your interface.',
			'default'     => 'https://realtimestaging.psigate.com/xml',
			
		),
		
				
		'publishable_key_cad' => array(
			'title'       => 'Live Real-time XML StoreID for CAD',
			'description' => 'PSiGate provides the StoreID within the PSiGate Welcome Email. StoreID is unique and case sensitive.',
			'type'        => 'text'
		),
		'private_key_cad' => array(
			'title'       => 'Live Real-time XML Passphrase for CAD',
			'description' => 'PSiGate provides the Passphrase within the PSiGate Welcome Email. Pass Phrase is case sensitive.',
			'type'        => 'password'
		),
		
		'cards_accepted_cad' => array(
			 'title' => 'Cards Accepted for DBA Store CAD',
			 'description' => 'Description for your option shown on the checkout page if seletced currency is CAD',
			 'type' => 'multiselect',
			 'class' => 'input-text regular-input',
			 'css' => 'CSS rules added line to the input',
			 'label' => 'Label', // checkbox only
		 'options' => array(
			  'visa' => 'VISA',
			  'visa_debit' => 'VISA Debit',
			  'interac_online' => 'Interac Online',
			  'mastercard' => 'Mastercard',
			  'mastercard_debit' => 'Mastercard Debit',			  
		 ) 
       ),
		
		'publishable_key_usd' => array(
			'title'       => 'Live Real-time XML StoreID for USD',
			'description' => 'PSiGate provides the StoreID within the PSiGate Welcome Email. StoreID is unique and case sensitive.',
			'type'        => 'text'
		),
		'private_key_cad_usd' => array(
			'title'       => 'Live Real-time XML Passphrase for USD',
			'description' => 'PSiGate provides the Passphrase within the PSiGate Welcome Email. Pass Phrase is case sensitive.',
			'type'        => 'password'
		),
		
			   
	   'cards_accepted_usd' => array(
			 'title' => 'Cards Accepted for DBA Store USD',
			 'description' => 'Description for your option shown on the checkout page if seletced currency is USD',
			 'type' => 'multiselect',
			 'class' => 'input-text regular-input',
			 'css' => 'CSS rules added line to the input',
			 'label' => 'Label', // checkbox only
		 'options' => array(
			  'visa' => 'VISA',
			  'visa_debit' => 'VISA Debit',
			  'mastercard' => 'Mastercard',
			  'mastercard_debit' => 'Mastercard Debit',			  
		 ) 
       ),
	   
	   'live_url' => array(
			'title'       => 'Realtime XML Live URL',
			'type'        => 'text',			
			'description' => 'Enter your live URL, received from PsiGate. Live Mode Only.',
						
		),
		
		
	);
   }
 
		/**
		 * You will need it if you want your custom credit card form, Step 4 is about it
		 */
		public function payment_fields() {
						// ok, let's display some description before the payment form
			    $wc_gateways      = new WC_Payment_Gateways();
                $payment_gateways = $wc_gateways->get_available_payment_gateways();
				//echo $payment_gateways['psigate']->enabled;
				$curr_currency=esc_attr(strtolower(get_woocommerce_currency()));
				//$payment_gateways['psigate']->form_fields['enabled']
				if($payment_gateways['psigate']->enabled=='yes' and $payment_gateways['psigate']->settings['enabled']=='yes'){
				
					if($this->description ) {
						// you can instructions for test mode, I mean test card numbers etc.
						if ( $this->testmode ) {
							$this->description = '<span style="color:red;">Payment gateway is currently test mode.</span>';
							//$this->description  = trim( $this->description );
						}
						// display the description with <p> tags etc.
						echo wpautop( wp_kses_post( $this->description ) );
					 }
				
					//echo '<pre>';
					//print_r($payment_gateways['psigate']);
					//echo '</pre>';

				// Loop through Woocommerce available payment gateways
					//foreach( $payment_gateways as $gateway_id => $gateway ){
						//$title        = $gateway->get_title();
						//$description  = $gateway->get_description();
						//$instructions = property_exists( $gateway , 'instructions' ) ? $gateway->instructions : '';
						//$icon         = $gateway->get_icon();
					//}
				
			   			   
			    if($curr_currency=='cad'){
				
				$card_opt=$payment_gateways['psigate']->form_fields['cards_accepted_cad']['options'];
				
				}else{
				
				$card_opt=$payment_gateways['psigate']->form_fields['cards_accepted_usd']['options'];
				} 
				
				//print_r($card_opt);
				
				
				// I will echo() the form, but you can close PHP tags and print it directly in HTML
				echo '<fieldset id="wc-' . esc_attr( $this->id ) . '-cc-form" class="wc-credit-card-form wc-payment-form" style="background:transparent;">';
			 
				// Add this action hook if you want your custom payment gateway to support it
				do_action( 'woocommerce_credit_card_form_start', $this->id );
			 
				// I recommend to use inique IDs, because other gateways could already use #ccNo, #expdate, #cvc
				echo '<style>.card_date_ex{width:48% !important;}.card_sec{width:47% !important;}@media only screen and (max-width: 768px) {.card_date_ex{width:42% !important;}.card_sec{width:100% !important;}}</style>

<div class="form-row form-row-first card_sec">
					<label>Card Number <span class="required">*</span></label>
					<input id="psigate_ccno" name="psigate_ccno" type="text" class="wooccm-required-field" autocomplete="off" placeholder="Card Number"  maxlength="16">
					</div>
					<div class="form-row form-row-last card_sec">
						<label>Card Accepted <span class="required"></span></label>
						<img src="https://www.solutions4unow.com/wp-content/uploads/2020/12/card_images.png" />
					</div>
					
					<div class="form-row form-row-first card_sec">
						<label>Expiry Date <span class="required">*</span></label>
						<input id="psigate_expmonth" name="psigate_expmonth" class="wooccm-required-field card_date_ex" type="text" autocomplete="off" placeholder="MM" maxlength="2">
						<input style="margin-right:0px;" id="psigate_expyear" name="psigate_expyear" class="wooccm-required-field card_date_ex" type="text" autocomplete="off" placeholder="YY" maxlength="2">
					</div>
					<div class="form-row form-row-last card_sec">
						<label>Card Code (CVC) <span class="required">*</span></label>
						<input id="psigate_cvv" name="psigate_cvv" type="password" class="wooccm-required-field" autocomplete="off" placeholder="CVC" maxlength="4">
					</div>
					<div class="clear"></div>';
			 
				do_action( 'woocommerce_credit_card_form_end', $this->id );
			 
				echo '<div class="clear"></div></fieldset>';
				
				}else{
				echo "PsiGate Gateway not enabled.";
				}
 
		}
 
		/*
		 * Custom CSS and JS, in most cases required only when you decided to go with a custom credit card form
		 */
	 	public function payment_scripts() {
 
		//...
 
	 	}
 
		/*
 		 * Fields validation, more in Step 5
		 */
		public function validate_fields() {
 
		if( empty( $_POST[ 'psigate_ccno' ]) ) {
		wc_add_notice(  'Ccno is required!', 'error' );
		return false;
	    }
		
		if( empty( $_POST[ 'psigate_cardtype' ]) ) {
		wc_add_notice(  'Card Type is required!', 'error' );
		return false;
	    }
		
		if( empty( $_POST[ 'psigate_expmonth' ]) ) {
		wc_add_notice(  'Exp. Month is required!', 'error' );
		return false;
	    }
		
		if( empty( $_POST[ 'psigate_expyear' ]) ) {
		wc_add_notice(  'Exp. Year is required!', 'error' );
		return false;
	    }
		if( empty( $_POST[ 'psigate_cvv' ]) ) {
		wc_add_notice(  'Cvv is required!', 'error' );
		return false;
	    }
		
	    return true;
 
		}
		
		
 
		/*
		 * We're processing the payments here, everything about it is in Step 5
		 */
		public function process_payment( $order_id ) {
 
			global $woocommerce;
			
			    $wc_gateways      = new WC_Payment_Gateways();
                $payment_gateways = $wc_gateways->get_available_payment_gateways();
				
				//echo $payment_gateways['psigate']->enabled;
				
				$curr_currency=esc_attr(strtolower(get_woocommerce_currency()));
				
				//$payment_gateways['psigate']->form_fields['enabled']
				
				if($payment_gateways['psigate']->enabled=='yes' and $payment_gateways['psigate']->settings['enabled']=='yes'){
				
				if($payment_gateways['psigate']->settings['testmode']=='yes'){
				 $StoreID=$payment_gateways['psigate']->settings['test_publishable_key'];
				 $Passphrase=$payment_gateways['psigate']->settings['test_private_key'];				 
				 $payment_url=$payment_gateways['psigate']->settings['test_url'];					
				}else{
						if($curr_currency=='cad'){
						 $StoreID=$payment_gateways['psigate']->settings['publishable_key_cad'];
						 $Passphrase=$payment_gateways['psigate']->settings['private_key_cad'];				 
						}else{
						 $StoreID=$payment_gateways['psigate']->settings['publishable_key_usd'];
						 $Passphrase=$payment_gateways['psigate']->settings['private_key_cad_usd'];				 
						} 
						
					$payment_url=$payment_gateways['psigate']->settings['live_url'];
			   }	
			
				// we need it to get any order detailes
				$order = wc_get_order( $order_id );
               $xml = '<?xml version="1.0" encoding="UTF-8"?><Order>
                <StoreID>'.$StoreID.'</StoreID>
                <Passphrase>'.$Passphrase.'</Passphrase>
                <Bname>'.$order->get_billing_first_name().'</Bname>
                <Bcompany>'.$order->get_billing_company().'</Bcompany>
                <Baddress1>'.$order->get_billing_address_1().'</Baddress1>
                <Baddress2>'.$order->get_billing_address_2().'</Baddress2>
                <Bcity>'.$order->get_billing_city().'</Bcity>
                <Bprovince>'.$order->get_billing_state().'</Bprovince>
                <Bpostalcode>'.$order->get_billing_postcode().'</Bpostalcode>
                <Bcountry>'.$order->get_billing_country().'</Bcountry>
				<CustomerIP>'.$order->get_customer_ip_address().'</CustomerIP>
                <Phone>'.$order->get_billing_phone().'</Phone>
                <Email>'.$order->get_billing_email().'</Email>
                <Comments>'.$_POST['order_comments'].'</Comments>';
			   
			    // Iterating through each "line" items in the order
				$i=1;
				foreach ($order->get_items() as $item_id => $item ) {
					// Get an instance of corresponding the WC_Product object
					$product        = $item->get_product();
					$active_price   = $product->get_price(); // The product active raw price
					$regular_price  = $product->get_sale_price(); // The product raw sale price
					$sale_price     = $product->get_regular_price(); // The product raw regular price
					$product_id     = $item->get_product_id(); // Get the item name (product name)
					$product_name   = $item->get_name(); // Get the item name (product name)
					$item_quantity  = $item->get_quantity(); // Get the item quantity
					$item_subtotal  = $item->get_subtotal(); // Get the item line total non discounted
					$item_subto_tax = $item->get_subtotal_tax(); // Get the item line total tax non discounted
					$item_total     = $item->get_total(); // Get the item line total discounted
					$item_total_tax = $item->get_total_tax(); // Get the item line total  tax discounted
					$item_taxes     = $item->get_taxes(); // Get the item taxes array
					$item_tax_class = $item->get_tax_class(); // Get the item tax class
					$item_tax_status= $item->get_tax_status(); // Get the item tax status
					
					$xml .= '<Item>
					<ItemID>'.$product_id.'</ItemID>
					<ItemDescription>'.$product_name.'</ItemDescription>
					<ItemQty>'.$item_quantity.'</ItemQty>
					<ItemPrice>'.$item_total.'</ItemPrice>
					</Item>';
					
					
					
				 $i++;
				}
				
				
				// Coupons used in the order LOOP (as they can be multiple)
				foreach( $order->get_used_coupons() as $coupon_code ){
				
					// Retrieving the coupon ID
					$coupon_post_obj = get_page_by_title($coupon_code, OBJECT, 'shop_coupon');
					$coupon_id       = $coupon_post_obj->ID;
				
					// Get an instance of WC_Coupon object in an array(necessary to use WC_Coupon methods)
					$coupon = new WC_Coupon($coupon_id);
					
					//echo '<pre>';
				    //print_r($coupon);
				   // echo '</pre>';				
					// Now you can get type in your condition
					if ( $coupon->get_discount_type() == 'cash_back_percentage' ){
						// Get the coupon object amount
						$coupon_amount1 = $coupon->get_amount();
						$xml .= '<Item>
						<ItemID>COUPON-'.$coupon->code().'</ItemID>
						<ItemDescription>'.$coupon->description().'-'.$coupon->code().'</ItemDescription>
						<ItemQty>1</ItemQty>
						<ItemPrice>-'.$coupon_amount1.'</ItemPrice>
						</Item>';
					}
				
					// Or use this other conditional method for coupon type
					if( $coupon->is_type( 'cash_back_fixed' ) ){
						// Get the coupon object amount
						$coupon_amount2 = $coupon->get_amount();
						$xml .= '<Item>
						<ItemID>COUPON-'.$coupon->code().'</ItemID>
						<ItemDescription>'.$coupon->description().'-'.$coupon->code().'</ItemDescription>
						<ItemQty>1</ItemQty>
						<ItemPrice>-'.$coupon_amount2.'</ItemPrice>
						</Item>';
					}
					
				}
				
		
			$xml .= '<Tax1>0.00</Tax1><ShippingTotal>'.$order->get_shipping_total().'</ShippingTotal>';
			
			if(!empty($_POST['psigate_ccno'])){
			  $psigate_ccno=$_POST['psigate_ccno'];
			 }
			
			if(!empty($_POST['psigate_expmonth'])){
			$psigate_expmonth=$_POST['psigate_expmonth'];
			}
			
			if(!empty($_POST['psigate_expyear'])){
			$psigate_expyear=$_POST['psigate_expyear'];
			}
			
			if(!empty($_POST['psigate_cvv'])){
			$psigate_cvv=$_POST['psigate_cvv'];
			}
			
			$xml .='<PaymentType>CC</PaymentType><CardAction>0</CardAction><CardNumber>'.$psigate_ccno.'</CardNumber><CardExpMonth>'.$psigate_expmonth.'</CardExpMonth><CardExpYear>'.$psigate_expyear.'</CardExpYear><CardIDNumber>'.$psigate_cvv.'</CardIDNumber></Order>';
			
			$URL =$payment_url;
			//setting the curl parameters.
			$ch = curl_init();
			curl_setopt($ch, CURLOPT_URL,$URL);
			curl_setopt($ch, CURLOPT_VERBOSE, 1);
			curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0);
			curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);
			curl_setopt($ch, CURLOPT_POST, 1);
			curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1); 
			curl_setopt($ch, CURLOPT_HTTPHEADER, array('Content-Type: application/xml'));
			curl_setopt($ch, CURLOPT_POSTFIELDS, $xml);
			if (curl_errno($ch)) 
			{
				// moving to display page to display curl errors
				 $error =curl_errno($ch).'<br/>';
				 $error .=curl_error($ch);
				 wc_add_notice($error,'error');
				 $order->update_status('failed');
		         return array(
				    'result'   => 'fail',
				    'redirect' => '',
		      	 );
			} 
			else 
			{
				//getting response from server
				$response = curl_exec($ch);
				$xml = simplexml_load_string($response);
				$json = json_encode($xml);
				$arr = json_decode($json,true);
				 //echo '<pre>';
				 //print_r($coupon);
				 //echo '</pre>';				 
				 // it could be different depending on your payment processor
				if($arr['Approved']== 'APPROVED') {
				// we received the payment
				$order->payment_complete();
				$order->reduce_order_stock();
				
				if (!empty($arr['ReturnCode'])) {
				update_post_meta($order_id,'ReturnCode',sanitize_text_field($arr['ReturnCode']));
				}
				
				if (!empty($arr['TransRefNumber'])) {
				update_post_meta($order_id,'TransRefNumber',sanitize_text_field($arr['TransRefNumber']));
				}
				
				if (!empty($arr['CardAuthNumber'])) {
				update_post_meta($order_id,'CardAuthNumber',sanitize_text_field($arr['CardAuthNumber']));
				}
				
				if (!empty($arr['CardRefNumber'])) {
				update_post_meta($order_id,'CardRefNumber',sanitize_text_field($arr['CardRefNumber']));
				}
				
				if (!empty($arr['OrderID'])) {
				update_post_meta($order_id,'OrderID',sanitize_text_field($arr['OrderID']));
				}
				
				// some notes to customer (replace true with false to make it private)
				$order->add_order_note( 'Hey, your order is paid! Thank you!', true );
				// Empty cart
				$woocommerce->cart->empty_cart();
				// Redirect to the thank you page
				return array(
					'result' => 'success',
					'redirect' => $this->get_return_url( $order )
				); 
				
			   }
			   curl_close($ch);	
				 
			}
		//*************************************** //
		}   
			   
		 
	}
 
		/*
		 * In case you need a webhook, like PayPal IPN etc
		 */
		public function webhook() {
 
		//...
 
	 	}
 	}
}