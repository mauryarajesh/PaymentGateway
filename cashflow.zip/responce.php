<?php
print_r($_POST);
$billName     = $_POST['bill_name'];
$billAddress  = $_POST['bill_address'];
echo $billPostcode = $_POST['bill_postcode'];
$billCountry  = $_POST['bill_country'];
$billEmail    = $_POST['bill_email'];
$billTel      = $_POST['bill_tel'];
$cartCost     = $_POST['cart_cost'];
$cartCurrency = $_POST['cart_currency'];
$cartId       = $_POST['cart_id'];
$cartDesc= $_POST['cart_desc'];
$tranRef      = $_POST['tran_ref'];
$tranTestmode = $_POST['tran_testmode'];
echo $authStatus   = $_POST['auth_status'];
$authCode     = $_POST['auth_code'];
$authMessage  = $_POST['auth_message'];
echo $authAVS      = $_POST['auth_avs'];
if($authStatus== "A" ) {
$recipient = "rajeshkumar.maurya@gmail.com";
}elseif($authStatus== "C" ) {
$recipient = "rajeshkumar.maurya@gmail.com";
}else {
$recipient ="rajeshkumar.maurya@gmail.com";
} 
$subject = "$tranStatus"." Website Order Received ".$tranRef." ".$billName;
$message = "Order Details\n\r";  
$message .= "".$cartDesc."\n\r";  
$message .= "".$cartCurrency." ".$cartCost."\n\n\r";  
$message .= "Customer Details\n\r";  
$message .= "".$billName."\n\r";  
$message .= "".$billAddress."\n\r";    
$message .= "".$billPostcode."\n\r";    
$message .= "".$billCountry."\n\r";    
$message .= "".$billEmail."\n\r";  
$message .= "".$billTel."\n\r";  
$message .= "Transaction Details\n\r";  
$message .= "tran_ref : ".$tranRef."\n\r";  
$message .= "tran_testmode : ".$tranTestmode."\n\r";  
$message .= "auth_avs : ".$authAVS."\n\r";  
$message .= "auth_status : ".$authStatus."\n\r";    
$message .= "auth_message : ".$authMessage."\n\r";    
$headers .= "From: sales@my-domain.com'\n";
$headers .= "Content-Type: text/plain; charset=iso-8859-1\n";
$headers .= "Reply-To: $email\n";
$headers .= "X-Priority: 1\n";
mail($recipient, $subject, $message, $headers);
?>
